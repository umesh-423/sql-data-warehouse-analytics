# SQL Data Warehouse Analytics

Exploratory and analytical SQL project built on a star-schema sales data
warehouse (AdventureWorks-style dataset). The project covers everything from
basic aggregation to window-function-based trend analysis, customer
segmentation, and a production-style reporting view.

## Dataset

| Table            | Grain                  | Rows   |
|-------------------|-------------------------|-------:|
| `fact_sales`      | one row per order line | 60,398 |
| `dim_customers`   | one row per customer    | 18,484 |
| `dim_products`    | one row per product     | 295    |

- Order dates span **Dec 2010 – Jan 2014**
- Total sales across the period: **$29.36M**
- Customers across 6 countries: Australia, United States, Canada, Germany,
  United Kingdom, France

Full schema and entity relationships: [`docs/data_model.md`](docs/data_model.md)

## Tech

- **T-SQL** (SQL Server / Azure Data Studio syntax — `DATETRUNC`, `DATEDIFF`,
  window functions, CTEs)
- CSV source data, loaded into a `gold` schema for analysis

## Project structure

```
sql-data-warehouse-analytics/
├── datasets/                       # Source CSVs
│   ├── dim_customers.csv
│   ├── dim_products.csv
│   └── fact_sales.csv
├── scripts/                        # Analysis scripts, run independently or in order
│   ├── 01_yearly_sales_summary.sql
│   ├── 02_cumulative_analysis.sql
│   ├── 03_product_performance_analysis.sql
│   ├── 04_part_to_whole_analysis.sql
│   ├── 05_product_cost_segmentation.sql
│   └── 06_customer_report_view.sql
├── docs/
│   └── data_model.md               # Star schema + ER diagram
└── README.md
```

## Analyses

| Script | What it answers |
|---|---|
| `01_yearly_sales_summary.sql` | How do total sales, active customers, and quantity sold trend year over year? |
| `02_cumulative_analysis.sql` | What's the running total of sales and moving average price, month over month? |
| `03_product_performance_analysis.sql` | Which products are performing above/below their own historical average, and up/down vs. the prior year? |
| `04_part_to_whole_analysis.sql` | What share of total revenue does each product category contribute? |
| `05_product_cost_segmentation.sql` | How is the product catalog distributed across cost bands? |
| `06_customer_report_view.sql` | A reusable `gold.report_customer` view: per-customer orders, spend, recency, lifespan, age group, and a VIP / Regular / New segment — built for consumption by a BI tool. |

## Sample insight

Bikes make up the large majority of revenue despite being a small share of
the catalog: of $29.36M total sales, **Bikes accounts for ~96.5%**, with
Accessories (~2.4%) and Clothing (~1.2%) making up the rest.

## How to run

1. Load the three CSVs in `datasets/` into a SQL Server (or compatible)
   database, in a schema named `gold` (tables: `gold.fact_sales`,
   `gold.dim_customers`, `gold.dim_products`).
2. Run the scripts in `scripts/` in numeric order — each is self-contained
   and commented.
3. `06_customer_report_view.sql` creates a view (`gold.report_customer`)
   intended to sit behind a BI tool such as Power BI or Tableau.

## Notes

This was built as a hands-on project to practice SQL window functions
(`SUM() OVER`, `LAG() OVER`), CTEs, and warehouse-style reporting patterns
(star schema, segmentation, VIP/Regular/New tiers) on a realistic-sized
dataset (~60K transactions).

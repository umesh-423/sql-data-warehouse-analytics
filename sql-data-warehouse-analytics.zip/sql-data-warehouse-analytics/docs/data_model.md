# Data Model

The `gold` layer follows a simple star schema: one fact table surrounded by
descriptive dimension tables.

```mermaid
erDiagram
    FACT_SALES }o--|| DIM_CUSTOMERS : customer_key
    FACT_SALES }o--|| DIM_PRODUCTS : product_key

    FACT_SALES {
        string order_number
        int product_key FK
        int customer_key FK
        date order_date
        date shipping_date
        date due_date
        int sales_amount
        int quantity
        int price
    }

    DIM_CUSTOMERS {
        int customer_key PK
        int customer_id
        string customer_number
        string first_name
        string last_name
        string country
        string marital_status
        string gender
        date birthdate
        date create_date
    }

    DIM_PRODUCTS {
        int product_key PK
        int product_id
        string product_number
        string product_name
        string category_id
        string category
        string subcategory
        string maintenance
        int cost
        string product_line
        date start_date
    }
```

| Table            | Grain                  | Rows   |
|-------------------|-------------------------|-------:|
| `fact_sales`      | one row per order line | 60,398 |
| `dim_customers`   | one row per customer    | 18,484 |
| `dim_products`    | one row per product     | 295    |

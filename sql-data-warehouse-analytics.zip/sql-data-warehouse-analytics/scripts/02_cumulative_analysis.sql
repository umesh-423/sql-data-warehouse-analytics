/*
===============================================================================
Cumulative Analysis
===============================================================================
Purpose:
    Track running total sales and moving average price by month, using
    window functions over a monthly-aggregated subquery.
===============================================================================
*/

SELECT
    order_date,
    total_sales,
    SUM(total_sales) OVER (ORDER BY order_date) AS running_total_sales,
    AVG(avg_price) OVER (ORDER BY order_date) AS moving_avg_price
FROM
(
    SELECT
        DATETRUNC(month, order_date) AS order_date,
        SUM(sales_amount) AS total_sales,
        AVG(price) AS avg_price
    FROM gold.fact_sales
    WHERE order_date IS NOT NULL
    GROUP BY DATETRUNC(month, order_date)
) monthly_sales
ORDER BY order_date;

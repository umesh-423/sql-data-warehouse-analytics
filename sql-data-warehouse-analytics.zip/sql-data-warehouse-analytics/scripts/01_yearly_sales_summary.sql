/*
===============================================================================
Yearly Sales Summary
===============================================================================
Purpose:
    Summarize total sales, unique customers, and quantity sold per year.
    Useful as a top-level check on overall business growth/decline.
===============================================================================
*/

SELECT
    YEAR(order_date) AS order_year,
    SUM(sales_amount) AS total_sales,
    COUNT(DISTINCT customer_key) AS total_customers,
    SUM(quantity) AS total_quantity
FROM gold.fact_sales
GROUP BY YEAR(order_date)
ORDER BY YEAR(order_date);

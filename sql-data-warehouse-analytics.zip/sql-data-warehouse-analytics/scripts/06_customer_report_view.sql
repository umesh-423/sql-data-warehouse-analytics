/*
===============================================================================
Customer Report View: gold.report_customer
===============================================================================
Purpose:
    Consolidate customer-level metrics (orders, sales, quantity, recency,
    lifespan) and derive segments (age group, VIP/Regular/New) for use in
    downstream reporting/BI tools.

Segmentation logic:
    - cust_segment:
        VIP     -> lifespan >= 12 months AND total_sales > 5000
        Regular -> lifespan >= 12 months AND total_sales <= 5000
        New     -> lifespan < 12 months
    - age_group: buckets of 10 years, from <20 up to 50+

Key metrics:
    - recency          months since last order
    - avg_order_val     total_sales / total_orders
    - avg_monthly_spend total_sales / lifespan (or total_sales if lifespan = 0)
===============================================================================
*/

CREATE VIEW gold.report_customer AS
WITH base_query AS (
    SELECT
        f.order_number,
        f.product_key,
        f.order_date,
        f.sales_amount,
        f.quantity,
        c.customer_key,
        c.customer_number,
        CONCAT(c.first_name, ' ', c.last_name) AS cust_name,
        DATEDIFF(year, c.birthdate, GETDATE()) AS age
    FROM gold.fact_sales f
    LEFT JOIN gold.dim_customers c
        ON c.customer_key = f.customer_key
    WHERE order_date IS NOT NULL
),
cust_agg AS (
    SELECT
        customer_key,
        customer_number,
        cust_name,
        age,
        COUNT(DISTINCT order_number) AS total_orders,
        SUM(sales_amount) AS total_sales,
        SUM(quantity) AS total_quantity,
        COUNT(DISTINCT product_key) AS total_products,
        MAX(order_date) AS last_order_date,
        DATEDIFF(month, MIN(order_date), MAX(order_date)) AS lifespan
    FROM base_query
    GROUP BY
        customer_key,
        customer_number,
        cust_name,
        age
)
SELECT
    customer_key,
    customer_number,
    cust_name,
    age,
    CASE
        WHEN age < 20 THEN 'Under 20'
        WHEN age BETWEEN 20 AND 29 THEN '20-29'
        WHEN age BETWEEN 30 AND 39 THEN '30-39'
        WHEN age BETWEEN 40 AND 49 THEN '40-49'
        ELSE '50 and above'
    END AS age_group,
    CASE
        WHEN lifespan >= 12 AND total_sales > 5000 THEN 'VIP'
        WHEN lifespan >= 12 AND total_sales <= 5000 THEN 'Regular'
        ELSE 'New'
    END AS cust_segment,
    total_orders,
    total_sales,
    total_quantity,
    total_products,
    last_order_date,
    DATEDIFF(month, last_order_date, GETDATE()) AS recency,
    lifespan,
    CASE
        WHEN total_orders = 0 THEN 0
        ELSE total_sales / total_orders
    END AS avg_order_val,
    CASE
        WHEN lifespan = 0 THEN total_sales
        ELSE total_sales / lifespan
    END AS avg_monthly_spend
FROM cust_agg;

-- Usage:
SELECT * FROM gold.report_customer;
